onEvent('recipes', event => {
        event.remove({output: 'tac:workbench'});//删除枪械工作台
    });