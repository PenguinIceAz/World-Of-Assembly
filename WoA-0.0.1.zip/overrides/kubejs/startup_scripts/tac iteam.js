onEvent('item.registry',event=>{
    event.create('kubejs:incomplete_9mm','create:sequenced_assembly')
        .texture('kubejs:item/kubejs:incomplete_9mm')
        .displayName('装配中的9MM子弹')
})